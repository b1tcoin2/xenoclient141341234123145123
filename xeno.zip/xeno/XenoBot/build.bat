@echo off
setlocal
rem Build XenoBot.exe (console subsystem).
rem Run from a "x64 Native Tools Command Prompt for VS 2022".

if not defined VCINSTALLDIR (
    echo [!] Run this from the x64 Native Tools Command Prompt.
    exit /b 1
)

cl /nologo /O2 /std:c++17 /EHsc /W4 /permissive- /DNDEBUG ^
   /D_UNICODE /DUNICODE ^
   XenoBot.cpp ^
   /link /SUBSYSTEM:CONSOLE ^
   winhttp.lib advapi32.lib ^
   /OUT:XenoBot.exe

if errorlevel 1 exit /b 1
echo [+] XenoBot.exe built
endlocal
