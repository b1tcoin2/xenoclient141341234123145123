@echo off
setlocal
rem MinGW-w64 build (WinLibs / MSYS2 UCRT64). No MSVC needed.
rem Usage: build-mingw.bat

where g++ >nul 2>&1
if errorlevel 1 (
    echo [!] g++ not on PATH. Add WinLibs\mingw64\bin or MSYS2 ucrt64\bin.
    exit /b 1
)

g++ -std=c++17 -O2 -municode -mwindows -static -static-libgcc -static-libstdc++ ^
    -DUNICODE -D_UNICODE -Wall -Wextra ^
    -I ..\XenoBot ^
    BuildXeno.cpp -o BuildXeno.exe ^
    -lwinhttp -lbcrypt -lcrypt32 -ladvapi32

if errorlevel 1 exit /b 1
echo [+] BuildXeno.exe built ^(mingw^)
endlocal
