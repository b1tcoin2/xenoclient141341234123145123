@echo off
setlocal
rem Start the bot from the repo root.
if not exist XenoBot\XenoBot.exe (
    echo [!] XenoBot.exe missing. Build it first:
    echo     cd XenoBot ^&^& build.bat
    exit /b 1
)
cd /d "%~dp0XenoBot"
XenoBot.exe
endlocal
